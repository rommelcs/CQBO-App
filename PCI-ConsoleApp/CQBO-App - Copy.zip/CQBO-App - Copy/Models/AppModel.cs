﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CQBO_App.Models
{
	class AppModel
	{
		public class RetEnv
		{
			public object retObj { get; set; }
			public string retCode { get; set; }
			public string retMesg { get; set; }
		}
	}
}
